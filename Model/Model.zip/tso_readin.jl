##readin targeted moments or auxiliary models
function Readin_moments(dir::String)

    #collect and return
    package_moments = []
    package_moments
end


#####read in model utilities (useful parameters or data estimated outside model)
function Readin_utilities(dir::String)

    #collect and return
    package = []
    package
end
